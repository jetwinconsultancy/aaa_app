PHPWord
=======

Non official repository for PHPWord.

This Repository is just a Github mirror from the official PHPWord project : http://phpword.codeplex.com/
