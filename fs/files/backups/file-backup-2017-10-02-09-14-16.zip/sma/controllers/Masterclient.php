<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Masterclient extends MY_Controller
{

    function __construct()
    {
        parent::__construct();

        if (!$this->loggedIn) {
            $this->session->set_userdata('requested_page', $this->uri->uri_string());
            redirect('login');
        }
        $this->load->library('form_validation');
        $this->load->model('db_model');
        $this->load->model('master_model');
    }

    public function index()
    {
        $this->data['error'] = (validation_errors() ? validation_errors() : $this->session->flashdata('error'));
        // $this->data['sales'] = $this->db_model->getLatestSales();
        // $this->data['quotes'] = $this->db_model->getLastestQuotes();
        // $this->data['purchases'] = $this->db_model->getLatestPurchases();
        // $this->data['transfers'] = $this->db_model->getLatestTransfers();
        // $this->data['customers'] = $this->db_model->getLatestCustomers();
        // $this->data['suppliers'] = $this->db_model->getLatestSuppliers();
        // $this->data['chatData'] = $this->db_model->getChartData();
        // $this->data['stock'] = $this->db_model->getStockValue();
        // $this->data['bs'] = $this->db_model->getBestSeller();
        // $this->data['users'] = $this->db_model->getUserList();
        // $lmsdate = date('Y-m-d', strtotime('first day of last month')) . ' 00:00:00';
        // $lmedate = date('Y-m-d', strtotime('last day of last month')) . ' 23:59:59';
        // $this->data['lmbs'] = $this->db_model->getBestSeller($lmsdate, $lmedate);
        $bc = array(array('link' => '#', 'page' => lang('Clients')));
        $meta = array('page_title' => lang('Clients'), 'bc' => $bc, 'page_name' => 'Clients');
		// $this->data['page_name'] = 'Clients';
        $this->page_construct('client/masterclient.php', $meta, $this->data);

    }
	
	public function add ()
	{
        $bc = array(array('link' => '#', 'page' => lang('Add Clients')));
        $meta = array('page_title' => lang('Add Clients'), 'bc' => $bc, 'page_name' => 'Add Clients');
		$this->data['sharetype'] = $this->master_model->get_all_share_type();
		$this->data['service'] = $this->master_model->get_all_service();
		$this->data['currency'] = $this->master_model->get_all_currency();
		$this->data['citizen'] = $this->master_model->get_all_citizen();
		$this->data['typeofdoc'] = $this->master_model->get_all_typeofdoc();
		$this->data['doccategory'] = $this->master_model->get_all_doccategory();
		// if ($this->session->userdata('unique_code') && $this->session->userdata('unique_code') != '')
		// {
			
			// $uq = $this->master_model->get_draft_add_company($this->session->userdata('username'));
			// if (isset($uq->unique_code))
			// {
			// $unique_code =$uq->unique_code;
			// } else $unique_code =$this->session->userdata('unique_code');
		// }
		$this->session->set_userdata('unique_code', $unique_code);
		// $this->data['unique_code'] = $unique_code;
		// $q = $this->db->get_where('officer', array('unique_code' => $unique_code));
        // if ($q->num_rows() > 0) {
            // foreach (($q->result()) as $row) {
                // $data[] = $row;
            // }
        // }
		// $officer = 
		$this->data['officer'] =$this->db_model->getOfficerUC($unique_code);
		// $this->sma->print_arrays($this->data);
        $this->page_construct('client/add_client.php', $meta, $this->data);
		
	}

	public function save()
	{
		$this->sma->print_arrays($_POST);
		// $this->sma->print_arrays($_POST,$_FILES);
		// Data Company Info
		$data['Slct_file_setup_for']=$_POST['Slct_file_setup_for'];
		$data['file_setup_for']=$_POST['file_setup_for'];
		$data['clientcode']=$_POST['clientcode'];
		$data['status']=$_POST['status'];
		$data['uen']=$_POST['uen'];
		// $data['file_setup1']=$_POST['file_setup1'];
		// $data['file_setup2']=$_POST['file_setup2'];
		$data['date_incorporation']=$_POST['date_incorporation'];
		$data['client_name']=$_POST['client_name'];
		$data['postal_code']=$_POST['postal_code'];
		$data['city']=$_POST['city'];
		$data['streetname']=$_POST['streetname'];
		$data['buildingname']=$_POST['buildingname'];
		$data['unitno']=$_POST['unitno'];
		$data['unitno1']=$_POST['unitno1'];
		$data['activity1']=$_POST['activity1'];
		$data['activity2']=$_POST['activity2'];
		$data['cp']=$_POST['cp'];
		$data['phone']=$_POST['phone'];
		$data['email']=$_POST['email'];
		$data['fax']=$_POST['fax'];
		if (isset($_POST['listedcompany']))    $data['listedcompany']=$_POST['listedcompany'];
		$data['chairman']=$_POST['chairman'];
		$data['formername']=$_POST['formername'];
	
		// Data Officer
		// $data['issued_amount_member']=$_POST['issued_amount_member'];
		// $data['issued_amount_member'][0]=$_POST['issued_amount_member'][0];
		// $data['no_of_share_member']=$_POST['no_of_share_member'];
		// $data['issued_currency_member']=$_POST['issued_currency_member'];
		// $data['issued_sharetype_member']=$_POST['issued_sharetype_member'];
		// $data['paid_amount_member']=$_POST['paid_amount_member'];
		// $data['paid_no_of_share_member']=$_POST['paid_no_of_share_member'];
		// $data['paid_currency_member']=$_POST['paid_currency_member'];
		// $data['paid_sharetype_member']=$_POST['paid_sharetype_member'];
		// $data['sharetype_member']=$_POST['sharetype_member'];
		// $data['currency_member']=$_POST['currency_member'];
		// $data['date']=$_POST['date'];
		$this->session->set_userdata('unique_code', '');
	}
	public function save_capital(){
		$unique_code = $_POST['unique_code'];
		$issued_amount_member = $_POST['issued_amount_member'];
		$no_of_share_member = $_POST['no_of_share_member'];
		$issued_currency_member = $_POST['issued_currency_member'];
		$issued_sharetype_member = $_POST['issued_sharetype_member'];
		// echo count($issued_amount_member);
		for ($i=0;$i<count($issued_amount_member);$i++)
		{
			$issued_sharetype = [];
			$issued_sharetype['unique_code'] = $unique_code;
			$issued_sharetype['issued_amount_member'] = $this->sma->remove_comma($issued_amount_member[$i]);
			$issued_sharetype['no_of_share_member'] = $this->sma->remove_comma($no_of_share_member[$i]);
			$issued_sharetype['issued_currency_member'] = $issued_currency_member[$i];
			$issued_sharetype['issued_sharetype_member'] = $issued_sharetype_member[$i];
			print_r($issued_sharetype);
			$q = $this->db->get_where("issued_sharetype", array("unique_code" => $unique_code, "issued_amount_member" => $issued_amount_member[$i],"no_of_share_member" => $no_of_share_member[$i],"issued_currency_member" => $issued_currency_member[$i]));
			if (!$q->num_rows())
			{
				$this->db->insert("issued_sharetype",$issued_sharetype);
			} else {
				$this->db->update("issued_sharetype",$issued_sharetype,array("unique_code" => $unique_code, "issued_amount_member" => $issued_sharetype['issued_amount_member'],"no_of_share_member" => $issued_sharetype['no_of_share_member'],"issued_currency_member" => $issued_currency_member[$i]));
			}
		}
		$paid_share= '';
		$paid_amount_member = $_POST['paid_amount_member'];
		$paid_no_of_share_member = $_POST['paid_no_of_share_member'];
		$paid_currency_member = $_POST['paid_currency_member'];
		$paid_sharetype_member = $_POST['paid_sharetype_member'];
		for ($i=0;$i<count($paid_amount_member);$i++)
		{
			$paid_share = [];
			$paid_share['unique_code'] = $unique_code;
			$paid_share['paid_amount_member'] = $this->sma->remove_comma($paid_amount_member[$i]);
			$paid_share['paid_no_of_share_member'] = $this->sma->remove_comma($paid_no_of_share_member[$i]);
			$paid_share['paid_currency_member'] = $paid_currency_member[$i];
			$paid_share['paid_sharetype_member'] = $paid_sharetype_member[$i];
			$q = $this->db->get_where("paid_share", array("unique_code" => $unique_code, "paid_amount_member" => $paid_share['paid_amount_member'],"paid_no_of_share_member" => $paid_share['paid_no_of_share_member'],"paid_currency_member" => $paid_currency_member[$i]));
			if (!$q->num_rows())
			{
				$this->db->insert("paid_share",$paid_share);
			} else {
				$this->db->update("paid_share",$paid_share,array("unique_code" => $unique_code, "paid_amount_member" => $paid_share['paid_amount_member'],"paid_no_of_share_member" => $paid_share['paid_no_of_share_member'],"paid_currency_member" => $paid_currency_member[$i]));
			}
		}
		$member_capital= '';
		$nama_member_capital = $_POST['nama_member_capital'];
		$sharetype_member = $_POST['sharetype_member'];
		$shares_member_capital = $_POST['shares_member_capital'];
		$no_share_paid_member_capital = $_POST['no_share_paid_member_capital'];
		$gid_member_capital = $_POST['gid_member_capital'];
		$currency_member_capital = $_POST['currency_member_capital'];
		$amount_share_member_capital = $_POST['amount_share_member_capital'];
		$amount_share_paid_member_capital = $_POST['amount_share_paid_member_capital'];
		for ($i=0;$i<count($nama_member_capital);$i++)
		{
			$member_capital = [];
			$member_capital['unique_code'] = $unique_code;
			$member_capital['nama_member_capital'] = $nama_member_capital[$i];
			$member_capital['sharetype_member'] = $sharetype_member[$i];
			$member_capital['shares_member_capital'] = $this->sma->remove_comma($shares_member_capital[$i]);
			$member_capital['no_share_paid_member_capital'] = $this->sma->remove_comma($no_share_paid_member_capital[$i]);
			$member_capital['gid_member_capital'] = $gid_member_capital[$i];
			$member_capital['currency_member_capital'] = $currency_member_capital[$i];
			$member_capital['amount_share_member_capital'] = $this->sma->remove_comma($amount_share_member_capital[$i]);
			$member_capital['amount_share_paid_member_capital'] = $this->sma->remove_comma($amount_share_paid_member_capital[$i]);
			$q = $this->db->get_where("member_capital", array("unique_code" => $unique_code, "nama_member_capital" => $nama_member_capital[$i]));
			if (!$q->num_rows())
			{
				$this->db->insert("member_capital",$member_capital);
			} else {
				$this->db->update("member_capital",$member_capital,array("unique_code" => $unique_code, "nama_member_capital" => $nama_member_capital[$i]));
			}
		}
		// $this->sma->print_arrays($_POST);
	}
	public function save_charges(){
		// $chargee= '';
		$unique_code = $_POST['unique_code'];
		$chargee_name = $_POST['chargee_name'];
		$chargee_nature_of = $_POST['chargee_nature_of'];
		$chargee_date_reg = $_POST['chargee_date_reg'];
		$chargee_no = $_POST['chargee_no'];
		$chargee_currency = $_POST['chargee_currency'];
		$chargee_amount = $_POST['chargee_amount'];
		$chargee_date_satisfied = $_POST['chargee_date_satisfied'];
		$chargee_satisfied_no = $_POST['chargee_satisfied_no'];
		// $amount_share_paid_member_capital = $_POST['amount_share_paid_member_capital'];
		for ($i=0;$i<count($chargee_name);$i++)
		{
			$chargee = [];
			$chargee['unique_code'] = $unique_code;
			$chargee['chargee_name'] = $chargee_name[$i];
			$chargee['chargee_nature_of'] = $chargee_nature_of[$i];
			$chargee['chargee_date_reg'] = $chargee_date_reg[$i];
			$chargee['chargee_no'] = $chargee_no[$i];
			$chargee['chargee_currency'] = $chargee_currency[$i];
			$chargee['chargee_amount'] = $chargee_amount[$i];
			$chargee['chargee_date_satisfied'] = $chargee_date_satisfied[$i];
			$chargee['chargee_satisfied_no'] = $chargee_satisfied_no[$i];
			$q = $this->db->get_where("chargee", array("unique_code" => $unique_code, "chargee_name" => $chargee_name[$i]));
			if (!$q->num_rows())
			{
				$this->db->insert("chargee",$chargee);
			} else {
				$this->db->update("chargee",$chargee,array("unique_code" => $unique_code, "chargee_name" => $chargee_name[$i]));
			}
		}
		print_r($chargee);
	}
	public function save_other(){
		$unique_code = $_POST['unique_code'];
		$client_others = [];
		$client_others['type_of_doc'] = $_POST['type_of_doc'];
		$client_others['others_category'] = $_POST['others_category'];
		$client_others['others_remarks'] = $_POST['others_remarks'];
		$q = $this->db->get_where("client_others", array("unique_code" => $unique_code, "type_of_doc" => $client_others['type_of_doc'], "others_category" => $client_others['others_category']));
		if (!$q->num_rows())
		{
			$this->db->insert("client_others",$client_others);
		} else {
			$this->db->update("client_others",$client_others,array("unique_code" => $unique_code, "type_of_doc" => $client_others['type_of_doc'], "others_category" => $client_others['others_category']));
		}
		print_r($client_others);
	}
	public function save_setup(){
		$this->sma->print_arrays($_POST);
	}
	public function add_officer ()
	{
		// $this->load->library('form_validation');
		// $this->load->helper('form');
		$data['unique_code']=$_POST['unique_code'];
		$data['nama']=$_POST['nama'];
		$data['gid']=$_POST['id'];
		// $q = $this->db->
		$d =$this->db_model->getOfficerGID($_POST['id']);
		print_r($d);
		if (count($d)> 0)
		{
			echo "Error";
		} else {
			$data['position']=$_POST['position'];
			$data['date_of_appointment']=$this->sma->fsd($_POST['date_of_appointment']);
			$data['date_of_cessation']=$this->sma->fsd($_POST['date_of_cessation']);
			$data['address']=$_POST['address'];
			$data['nationality']=$_POST['nationality'];
			$data['citizen']=$_POST['citizen'];
			$data['date_of_birth']=$this->sma->fsd($_POST['date_of_birth']);
			$this->db->insert("officer",$data);
			echo $this->db->insert_id();
		}
		$this->sma->print_arrays($data);		
		
	}
	public function delete_officer ($id)
	{
		echo $this->db->delete("officer",array('id'=>$id));
	}
	
	public function edit ()
	{
        $bc = array(array('link' => '#', 'page' => lang('Edit Clients')));
        $meta = array('page_title' => lang('Edit Clients'), 'bc' => $bc, 'page_name' => 'Edit Clients');
		// $this->data['page_name'] = 'Clients';
        $this->page_construct('client/edit_client.php', $meta, $this->data);
		
	}
	
	public function buyback ()
	{
        $bc = array(array('link' => '#', 'page' => lang('Buy Back')));
        $meta = array('page_title' => lang('Buy Back'), 'bc' => $bc, 'page_name' => 'Buy Back');
		// $this->data['page_name'] = 'Clients';
        $this->page_construct('client/buyback.php', $meta, $this->data);
		
	}
	
	public function allotment ()
	{
        $bc = array(array('link' => '#', 'page' => lang('Allotment')));
        $meta = array('page_title' => lang('Allotment'), 'bc' => $bc, 'page_name' => 'Allotment');
		// $this->data['page_name'] = 'Clients';
        $this->page_construct('client/allotment.php', $meta, $this->data);
		
	}
	
	public function transfer ()
	{
        $bc = array(array('link' => '#', 'page' => lang('Transfer')));
        $meta = array('page_title' => lang('Transfer'), 'bc' => $bc, 'page_name' => 'Transfer');
		// $this->data['page_name'] = 'Clients';
        $this->page_construct('client/transfer.php', $meta, $this->data);
		
	}
	
	public function unpaid_invoice ()
	{
        $bc = array(array('link' => '#', 'page' => lang('Unpaid Invoice')));
        $meta = array('page_title' => lang('Unpaid Invoice'), 'bc' => $bc, 'page_name' => 'Unpaid Invoice');
		// $this->data['page_name'] = 'Clients';
        $this->page_construct('client/unpaid.php', $meta, $this->data);
		
	}
	
	public function create_billing ()
	{
        $bc = array(array('link' => '#', 'page' => lang('Create Billing')));
        $meta = array('page_title' => lang('Create Billing'), 'bc' => $bc, 'page_name' => 'Create Billing');
		// $this->data['page_name'] = 'Clients';
        $this->page_construct('client/create_billing.php', $meta, $this->data);
		
	}
	
	public function unreceived_doc ()
	{
        $bc = array(array('link' => '#', 'page' => lang('Unreceived Document')));
        $meta = array('page_title' => lang('Unreceived Document'), 'bc' => $bc, 'page_name' => 'Unreceived Document');
		// $this->data['page_name'] = 'Clients';
        $this->page_construct('client/unreceived.php', $meta, $this->data);
		
	}
	
	public function setting_filing ()
	{
        $bc = array(array('link' => '#', 'page' => lang('Filing')));
        $meta = array('page_title' => lang('Filing'), 'bc' => $bc, 'page_name' => 'Filing');
		// $this->data['page_name'] = 'Clients';
        $this->page_construct('client/setting_filing.php', $meta, $this->data);
		
	}
	
	public function modal_next ()
	{
		print_r($_POST);
        $bc = array(array('link' => '#', 'page' => lang('Confirm Changes Clients')));
        $meta = array('page_title' => lang('Confirm Changes  Clients'), 'bc' => $bc, 'page_name' => 'Confirm Changes  Clients');
		// $this->data['page_name'] = 'Clients';
        $this->page_construct('client/confirm_changes.php', $meta, $this->data);
		
	}

}
