<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Personprofile extends MY_Controller
{

    function __construct()
    {
        parent::__construct();

        if (!$this->loggedIn) {
            $this->session->set_userdata('requested_page', $this->uri->uri_string());
            redirect('login');
        }
        $this->load->library('form_validation');
        $this->load->model('db_model');
    }

    public function index()
    {
        $this->data['error'] = (validation_errors() ? validation_errors() : $this->session->flashdata('error'));
        $bc = array(array('link' => '#', 'page' => lang('Person')));
        $meta = array('page_title' => lang('Person'), 'bc' => $bc, 'page_name' => 'Person');
        $this->page_construct('personprofile.php', $meta, $this->data);

    }

    public function add()
    {
        $this->data['error'] = (validation_errors() ? validation_errors() : $this->session->flashdata('error'));
        $bc = array(array('link' => '#', 'page' => lang('Add Person Profile')));
        $meta = array('page_title' => lang('Add Person Profile'), 'bc' => $bc, 'page_name' => 'Add Person Profile');
        $this->page_construct('addpersonprofile.php', $meta, $this->data);

    }

    public function edit()
    {
        $this->data['error'] = (validation_errors() ? validation_errors() : $this->session->flashdata('error'));
        $bc = array(array('link' => '#', 'page' => lang('Edit Person Profile')));
        $meta = array('page_title' => lang('Edit Person Profile'), 'bc' => $bc, 'page_name' => 'Edit Person Profile');
        $this->page_construct('addpersonprofile.php', $meta, $this->data);

    }

}
