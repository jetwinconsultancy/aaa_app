<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Setting extends MY_Controller
{

    function __construct()
    {
        parent::__construct();

        if (!$this->loggedIn) {
            $this->session->set_userdata('requested_page', $this->uri->uri_string());
            redirect('login');
        }
        $this->load->library('form_validation');
        $this->load->model('db_model');
    }

    public function index()
    {
        $this->data['error'] = (validation_errors() ? validation_errors() : $this->session->flashdata('error'));
        $bc = array(array('link' => '#', 'page' => lang('Setting')));
        $meta = array('page_title' => lang('Setting'), 'bc' => $bc, 'page_name' => 'Setting');
        $this->page_construct('setting.php', $meta, $this->data);

    }
}