<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/*
 * Language: English
 * Module: Notificationss
 * 
 * Last edited:
 * 1st December 2014
 *
 * Package:
 * Stock Manage Advance v3.0
 * 
 * You can translate this file to your language. 
 * For instruction on new language setup, please visit the documentations. 
 * You alseo can share your language files by emailing to saleem@tecdiary.com 
 * Thank you 
 */

$lang['notification'] = "Pemberitahuan";
$lang['add_notification'] = "Pemberitahuan Baru";
$lang['edit_notification'] = "Ubah Pemberitahuan";
$lang['delete_notification'] = "Hapus Pemberitahuan";
$lang['delete_notifications'] = "Hapus Pemberitahuan";
$lang['notification_added'] = "Pemberitahuan Berhasil Ditambahkan";
$lang['notification_updated'] = "Pemberitahuan Berhasil Diperbaharui";
$lang['notification_deleted'] = "Pemberitahuan Berhasil Dihapus";
$lang['notifications_deleted'] = "Pemberitahuan Berhasil Dihapus";
$lang['submitted_at'] = "Submit pada";
$lang['till'] = "Sampai";
$lang['comment'] = "Komentar";
$lang['for_customers_only'] = "Hanya Untuk Pelanggan";
$lang['for_staff_only'] = "Hanya Untuk Karyawan";
$lang['for_both'] = "Untuk Keduanya";
$lang['till'] = "Sampai";