<section class="panel">
	<div class="panel-body">
		<div class="col-md-12">
			<div id="modal_allotment" class="">
				<section id="wAllotment">
				<div class="panel-body">
					<div class="wizard-progress wizard-progress-lg">
						<div class="steps-progress">
							<div class="progress-indicator"></div>
						</div>
						<ul class="wizard-steps">
							<li class="active">
								<a href="#alloment_number_shares" data-toggle="tab"><span>1</span>Number Shares</a>
							</li>
							<li>
								<a href="#allotment_member" data-toggle="tab"><span>2</span>Members</a>
							</li>
							<li>
								<a href="#allotment_confirm" data-toggle="tab"><span>3</span>Confirmation</a>
							</li>
						</ul>
					</div>
	
					<form class="form-horizontal" novalidate="novalidate">
						<div class="tab-content">
							<div id="alloment_number_shares" class="tab-pane active">
								<div class="form-group">
									<label class="col-sm-5 control-label">Date</label>
									<div class="col-sm-3">
										<input type="text" class="form-control" name="date" data-date-format="dd/mm/yyyy" data-plugin-datepicker required>
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-5 control-label" for="allotment_sharetype">Share Type</label>
									<div class="col-sm-3">
										
										<select class="form-control">
											<option>ORDINARY</option>
											<option>Share Type 1</option>
											<option>Share Type 2</option>
											<option>Share Type 3</option>
										</select>
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-5 control-label" for="allotment_sharetype">Currency</label>
									<div class="col-sm-3">
										
										<select class="form-control">
											<option>SGD</option>
											<option>USD</option>
										</select>
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-5 control-label" for="Allotment_Share">No of Share</label>
									<div class="col-sm-3">
										<input type="text" class="form-control number text-right" name="Allotment_Share" id="Allotment_Share" value="1,000" required>
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-5 control-label" for="Allotment_Share_amount">Amount</label>
									<div class="col-sm-3">
										<input type="text" class="form-control number text-right" name="Allotment_Share_amount" id="Allotment_Share_amount" value="1,000.00" required>
									</div>
								</div>
							</div>
							<div id="allotment_member" class="tab-pane">
								<div class="col-md-12">
									<div class="col-md-8">
										<select class="input-sm" style="float:left;">
											<option>ID</option>
											<option>Name</option>
										</select>
										<div class="col-md-6 input-group" style="float:left;margin-left:5px;">
											<input type="text" class="form-control input-sm" id="w2-username" name="username" placeholder="Search">
											<span class="input-group-btn">
												<button class="btn btn-default" type="submit" style="height:30px;"><i class="fa fa-search"></i></button>
											</span>
										</div>
									</div>
									<div class="col-md-6" style="margin-top:5px;">
										<table class="table table-bordered table-striped table-condensed mb-none" >
											<thead>
												<tr>
													<th>ID</th>
													<th>Name</th>
													<th width=20px></th>
												</tr>
											</thead>
											<tbody>
												<tr>
													<td>x1y2z3</td>
													<td>Person 1</td>
													<td><button class="add_director">Add</button></td>
												</tr>
												<tr>
													<td>Abcde</td>
													<td>Person 2</td>
													<td><button class="add_director">Add</button></td>
												</tr>
												<tr>
													<td>Efghi</td>
													<td>Person 3</td>
													<td><button class="add_director">Add</button></td>
												</tr>
											</tbody>
										</table>
										<br/>
									</div>
								</div><table  class="table table-bordered table-striped table-condensed mb-none">
									<tr>
										<th>No.</th>
										<th>ID</th>
										<th>Name</th>
										<th>Share</th>
										<th>Amount</th>
										<th>Share Paid</th>
										<th>Amount Paid</th>
										<th>Certificate No.</th>
									</tr>
									<tr>
										<td>1</td>
										<td>
											<div>
												<input type="text" class="form-control" value="S8484841Z" required>
											</div>
										</td>
										<td>
											<div>
												<input type="text" class="form-control" value="Dart" required>
											</div>
										</td>
										<td>
											<div>
												<input type="text" class="form-control number text-right" value="100" required>
											</div>
										</td>
										<td>
											<div>
												<input type="text" class="form-control number text-right" value="1,000.00" required>
											</div>
										</td>
										<td>
											<div>
												<input type="text" class="form-control number text-right" value="100" required>
											</div>
										</td>
										<td>
											<div>
												<input type="text" class="form-control number text-right" value="1,000.00" required>
											</div>
										</td>
										<td>
											<div>
												<input type="text" class="form-control" value="CRT1199191" required>
											</div>
										</td>
										<td>
											<a href="#"><i class="fa fa-trash"></i></a>
										</td>
									</tr>
									<tr>
										<td>2</td>
										<td>
											<div>
												<input type="text" class="form-control" value="S2525252Z" required>
											</div>
										</td>	
										<td>
											<div>
												<input type="text" class="form-control" value="Vart" required>
											</div>
										</td>
										<td>
											<div>
												<input type="text" class="form-control number text-right" value="80" required>
											</div>
										</td>
										<td>
											<div>
												<input type="text" class="form-control number text-right" value="800.00" required>
											</div>
										</td>
										<td>
											<div>
												<input type="text" class="form-control number text-right" value="80" required>
											</div>
										</td>
										<td>
											<div>
												<input type="text" class="form-control number text-right" value="800.00" required>
											</div>
										</td>
										<td>
											<div>
												<input type="text" class="form-control" value="CRT1199191" required>
											</div>
										</td>
										<td>
											<a href="#"><i class="fa fa-trash"></i></a>
										</td>
									</tr>
								</table>
							</div>
							<div id="allotment_confirm" class="tab-pane">
								<div class="form-group">
									<table class="table table-bordered table-condensed">
										<tr>
											<td>ID</td>
											<td>Name</td>
											<td>No Of Shares Paid</td>
											<td>Amount Shares</td>
										</tr>
										<tr>
											<td width=80px>SG345678</td>
											<td>Dart</td>
											<td width=140px class="text-right">10,000</td>
											<td width=140px class="text-right">$1,000,000.00</td>
										</tr>
										<tr>
											<td>SG123123123</td>
											<td>Durt</td>
											<td class="text-right">1,000</td>
											<td class="text-right">$100,000.00</td>
										</tr>
									</table>
								</div>
								<div class="form-group" style="padding-left:25px;">
									<div class="form-group">
										<label>Certificate:</label>
									</div>
									<div class="form-group">
										<label><input type="radio" name="certificate" class="unmanual">&nbsp;&nbsp;&nbsp;Cancel all existing and replace with new certificate</label>
									</div>
									<div class="form-group">
										<label><input type="radio" name="certificate" class="unmanual">&nbsp;&nbsp;&nbsp;New certificate number for shares alloted</label>
									</div>
									<div class="form-group">
										<label><input type="radio" name="certificate"  id="manual">&nbsp;&nbsp;&nbsp;Manual Changes</label>
										<table class="table table-striped" id="A" style="display:none" >
											<tr>
												<td>No</td>
												<td>Date</td>
												<td>Members</td>
												<td>Share</td>
												<td>Certificate</td>
											</tr>
											<tr>
												<td>1</td>
												<td>01/01/2016</td>
												<td>Durt</td>
												<td>1000</td>
												<td><a>CRT118888</a></td>
											</tr>
										</table>
									</div>
								</div>
							</div>
						</div>
					</form>
				
				

				</div>
				
				<div class="panel-footer">
					<ul class="pager">
						<li class="previous disabled">
							<a><i class="fa fa-angle-left"></i> Previous</a>
						</li>
						<li class="finish  modal-dismiss hidden pull-right">
							<a>Save</a>
						</li>
						<li class="next">
							<a>Next <i class="fa fa-angle-right"></i></a>
						</li>
					</ul>
				</div>	
				</section>
			</div>
		</div>
	</div>
	
<!-- end: page -->
</section>
<script>
	$(document).on('click','#manual',function(){
		$("#A").show();
	});
	$(document).on('click','.unmanual',function(){
		$("#A").hide();
	});
</script>