<section class="panel">
	<div class="panel-body">
			<div id="modal_buyback" class="">
										<section class="panel" id="wBuyback">
											<div class="panel-body">
												<div class="wizard-progress wizard-progress-lg">
													<div class="steps-progress">
														<div class="progress-indicator"></div>
													</div>
													<ul class="wizard-steps">
														<li class="active">
															<a href="#buyback_number_shares" data-toggle="tab"><span>1</span>Shares</a>
														</li>
														<li>
															<a href="#buyback_member" data-toggle="tab" id="calculate_buyback"><span>2</span>Member</a>
														</li>
														<li>
															<a href="#allotment_confirm" data-toggle="tab"><span>3</span>Confirmation</a>
														</li>
													</ul>
												</div>
								
												<form class="form-horizontal" novalidate="novalidate">
													<div class="tab-content">
														<div id="buyback_number_shares" class="tab-pane active">
															<div class="form-group">
																<label class="col-sm-5 control-label">Date</label>
																<div class="col-sm-3">
																	<input type="text" class="form-control" data-date-format="dd/mm/yyyy" data-plugin-datepicker required>
																</div>
															</div>
															<div class="form-group">
																<label class="col-sm-5 control-label" for="allotment_sharetype">Share Type</label>
																<div class="col-sm-3">
																	
																	<select class="form-control">
																		<option>ORDINARY</option>
																		<option>Share Type 1</option>
																		<option>Share Type 2</option>
																			<option>Share Type 3</option>
																	</select>
																</div>
															</div>
															<div class="form-group">
																<label class="col-sm-5 control-label" for="allotment_sharetype">Currency</label>
																<div class="col-sm-3">
																	
																	<select class="form-control">
																		<option>SGD</option>
																		<option>USD</option>
																	</select>
																</div>
															</div>
															<div class="form-group">
																<label class="col-sm-5 control-label" for="Allotment_Share">Buyback Share (%)</label>
																<div class="col-sm-3">
																	<input type="number" class="form-control text-right" max-value="100" name="Allotment_Share" id="Allotment_Share" value="100"  required>
																</div>
															</div>
															<div class="form-group">
																<label class="col-sm-5 control-label" for="Allotment_Share_amount">Share Amount</label>
																<div class="col-sm-3">
																	<input type="text" class="form-control text-right" name="Allotment_Share_amount" id="Allotment_Share_amount"  value="10,000.00" required>
																</div>
															</div>
														</div>
														<div id="buyback_member" class="tab-pane">
															<h1>Total Share Buyback : <span id="t_s_bb"> </span></h1>
															<table  class="table table-bordered table-striped table-condensed mb-none">
																<tr>
																	<th>No.</th>
																	<th>Name</th>
																	<th>ID</th>
																	<th>Share</th>
																	<th>Amount</th>
																	<th>Share Buyback</th>
																	<th>Amount Paid</th>
																	<th>Certificate No.</th>
																</tr>
																<tr>
																	<td>1</td>
																	<td>
																			Dart
																	</td>
																	<td>
																		S8484841Z
																	</td>
																	<td>
																		<div>
																			<input type="text" id="shareori_bb1" class="form-control number  text-right" value="1,000" readonly>
																		</div>
																	</td>
																	<td>
																		<div>
																			<input type="text" id="amountori_bb1" class="form-control  number text-right" value="1,000.00" readonly>
																		</div>
																	</td>
																	<td>
																		<div>
																			<input type="text" class="share_bb form-control number  text-right" data-id=1 value="1,000" required>
																		</div>
																	</td>
																	<td>
																		<div>
																			<input type="text" id="amount_bb1" class="form-control  number text-right" value="1,000.00" required>
																		</div>
																	</td>
																	<td>
																		<div>
																			<input type="text" class="form-control" value="CRT1199191" required>
																		</div>
																	</td>
																</tr>
																<tr>
																	<td>2</td>
																	<td>
																		Durt
																	</td>
																	<td>
																		S7272727Z
																	</td>
																	<td>
																		<div>
																			<input type="text" id="shareori_bb2" class=" form-control  number text-right" value="1,000" readonly>
																		</div>
																	</td>
																	<td>
																		<div>
																			<input type="text" id="amountori_bb2" class=" form-control  number text-right" value="1,000.00" readonly>
																		</div>
																	</td>
																	<td>
																		<div>
																		<input type="text" class="share_bb form-control  number text-right" data-id="2" value="1,000" required>
																		</div>
																	</td>
																	<td>
																		<div>
																			<input type="text" id="amount_bb2" class=" form-control number text-right" value="1,000.00" required>
																		</div>
																	</td>
																	<td>
																		<div>
																			<input type="text" class="form-control" value="CRT22333441" required>
																		</div>
																	</td>
																</tr>
																<tr>
																	<td colspan=3>Total</td>
																	<td id="total_Share"></td>
																	<td id="total_amount"></td>
																	<td id="total_shareBB"></td>
																	<td id="total_amountBB"></td>
																	<td id=""></td>
																</tr>	
															</table>
														</div>
														<div id="allotment_confirm" class="tab-pane">
															<table class="table table-bordered">
																<tr>
																	<td>No</td>
																	<td>Name</td>
																	<td>Share</td>
																	<td>Amount</td>
																	<td>Share Buyback</td>
																	<td>Amount Buyback</td>
																	<td>Total Share</td>
																	<td>Total Amount</td>
																</tr>
																<tr>
																	<td>1</td>
																	<td>Dart</td>
																	<td align=right>100</td>
																	<td align=right>1,000</td>
																	<td align=right>15</td>
																	<td align=right>6,666.67</td>
																	<td align=right>115</td>
																	<td align=right>7,666.67</td>
																</tr>
																<tr>
																	<td>2</td>
																	<td>Durt</td>
																	<td align=right>100</td>
																	<td align=right>1,000</td>
																	<td align=right>15</td>
																	<td align=right>6,666.67</td>
																	<td align=right>115</td>
																	<td align=right>7,666.67</td>
																</tr>
															</table>
															
															<div class="form-group" style="padding-left:25px;">
																<div class="form-group">
																	<label>Certificate:</label>
																</div>
																<div class="form-group">
																	<label><input type="radio" name="certificate" class="unmanual">&nbsp;&nbsp;&nbsp;Cancel all existing and replace with new certificate</label>
																</div>
																<div class="form-group">
																	<label><input type="radio" name="certificate" class="unmanual">&nbsp;&nbsp;&nbsp;New certificate number for shares alloted</label>
																</div>
																<div class="form-group">
																	<label><input type="radio" name="certificate"  id="manual">&nbsp;&nbsp;&nbsp;Manual Changes</label>
																	<table class="table table-striped" id="A" style="display:none" >
																		<tr>
																			<td>No</td>
																			<td>Date</td>
																			<td>Members</td>
																			<td>Share</td>
																			<td>Certificate</td>
																		</tr>
																		<tr>
																			<td>1</td>
																			<td>01/01/2016</td>
																			<td>Durt</td>
																			<td>1000</td>
																			<td><a>CRT118888</a></td>
																		</tr>
																	</table>
																</div>
															</div>
														</div>
													</div>
												</form>
														
														
						
											</div>
											<div class="">
												<ul class="pager">
													<li class="previous disabled">
														<a><i class="fa fa-angle-left"></i> Previous</a>
													</li>
													<li class="finish  modal-dismiss hidden pull-right">
														<a>Save</a>
													</li>
													<li class="next">
														<a>Next <i class="fa fa-angle-right"></i></a>
													</li>
												</ul>
											</div>
										</section>
									</div>
					
	</div>
	
<!-- end: page -->
</section>

<script>
	$(document).on('click','#manual',function(){
		$("#A").show();
	});
	$(document).on('click','.unmanual',function(){
		$("#A").hide();
	});
	$(document).on('blur','#Allotment_Share',function(){
		if ($(this).val() >100)
		{
			$(this).val(100);
		} else if ($(this).val() <0)
		{
			$(this).val(0);
		}
	});
</script>