	<section class="panel">
			<div class="panel-body">
				<div class="modal-wrapper">
					<div class="modal-text">
						<div class="tabs">
		<form class="form-horizontal" novalidate="novalidate">
			<div class="tab-content">
				<div id="w2-account" class="tab-pane active">
					<table class="table table-bordered table-striped table-condensed mb-none">
					<thead>
			<tr style="background-color:white;">
				<td class="text-center" style="font-weight:bold;">Tabs</th>
				<td class="text-center" style="font-weight:bold;">Changes Made</th>
				<td class="text-center" style="font-weight:bold;">Existing</th>
				<td class="text-center" style="font-weight:bold;">New</th>
			</tr>
			</thead>
		<tbody>
			<tr>
				<td class="text-left">Company Info</td>
				<td class="text-left">Company Name</td>
				<td class="text-center">XXXX</td>
				<td class="text-center">YYYY</td>
			</tr>
			<tr>
				<td class="text-left">Company Info</td>
				<td class="text-left">Building Name</td>
				<td class="text-center">AAAA</td>
				<td class="text-center">BBBB</td>
			</tr>
			<tr>
				<td class="text-left">Director</td>
				<td class="text-left">Dart -> Share Paid</td>
				<td class="text-center">10,000</td>
				<td class="text-center">100,000</td>
			</tr>
			<tr>
				<td class="text-left">Transfer</td>
				<td class="text-left">Dart -(1,000)</td>
				<td class="text-center">100,000</td>
				<td class="text-center">99,000</td>
			</tr>
			<tr>
				<td class="text-left">Transfer</td>
				<td class="text-left">Durt -(200)</td>
				<td class="text-center">10,000</td>
				<td class="text-center">9,800</td>
			</tr>
			<tr>
				<td class="text-left">Transfer</td>
				<td class="text-left">Dort +(1,200)</td>
				<td class="text-center">1,000</td>
				<td class="text-center">2,200</td>
			</tr>
			<tr>	
				<td class="text-left">Billing Info</td>
				<td class="text-left">Service 2 (Edit)</td>
				<td class="text-center">500</td>
				<td class="text-center">700</td>
			</tr>
			<tr>	
				<td class="text-left">Billing Info</td>
				<td class="text-left">Service 3 (ADD)</td>
				<td class="text-center">-</td>
				<td class="text-center">1,200</td>
			</tr>
		</tbody>
	</table>
				</div>
			</div>
		</form>
	</div>
					</div>
				</div>
			</div>
			<footer class="panel-footer">
				<div class="row">
					<div class="col-md-12 number text-right">
						<a href="<?= base_url();?>masterclient/add"><button class="btn btn-default">Back To Edit</button></a>
						<a href=""><button class="btn btn-primary modal-dismiss">Print</button></a>
						<a  href=""><button class="btn btn-primary modal-dismiss">Save</button></a>
					</div>
				</div>
			</footer>
		</section>
	