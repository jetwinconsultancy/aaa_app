<section class="panel">
								
								<div class="panel-body">
									<div class="col-md-12">
										<div class="row datatables-header form-inline">
											<div class="col-sm-12">
														<select class="form-control">
															<option>Company Name</option>
															<option>Former Name</option>
															<option>UEN</option>
														</select>
														<input aria-controls="datatable-default" placeholder="Search" class="form-control" type="search">
															<label class="control-label">Date range</label>
																<div class="input-daterange input-group" data-plugin-datepicker>
																	<span class="input-group-addon">
																		<i class="fa fa-calendar"></i>
																	</span>
																	<input type="text" class="form-control" name="start">
																	<span class="input-group-addon">to</span>
																	<input type="text" class="form-control" name="end">
																</div>
														<button name="search" type="button" id="button" class="btn btn-primary" tabindex="-1">search</button>
												
											</div>
										</div>
											<div id="buttonclick" style="display:none">
												<!--
												<div class="col-sm-12 col-md-6">
													<div id="datatable-default_length" class="dataTables_length">
														<label>
															<select class="" aria-controls="datatable-default" name="datatable-default_length">
															<option value="10">10</option>
															<option value="25">25</option>
															<option value="50">50</option>
															<option value="100">100</option>
															</select> records per page</label>
													</div>
												</div>
												-->
												<h3></h3>
												<table class="table table-bordered table-striped mb-none" id="datatable-default">
													<thead>
													<tr>
														<th>No</th>
														<th>Company Name</th>
														<th>Document</th>
														<th>Date Created</th>
														<th>Date Upload</th>
														<th>PIC</th>
														<th></th>
													</tr>
													</thead>
													<tr>
														<td>1</td>
														<td>XXX LTE</td>
														<td>Akta Notaris</td>
														<td>02/05/2016</td>
														<td>02/05/2016</td>
														<td>Admin</td>
														<td><a href="#">Preview</a>
															<a href="#">Replace</a></td>
													</tr>
													<tr>
														<td>2</td>
														<td>XXX LTE</td>
														<td>Memorandum</td>
														<td>02/05/2016</td>
														<td></td>
														<td>User</td>
														<td><a href="#">Preview</a>
															<a href="#">Replace</a></td>
													</tr>
													<tr>
														<td>3</td>
														<td>YYY PTE</td>
														<td>ID CARD MR. XXXX</td>
														<td>02/05/2016</td>
														<td>02/05/2016</td>
														<td>User</td>
														<td><a href="#">Preview</a>
															<a href="#">Replace</a></td>
													</tr>
													<tr>
														<td>4</td>
														<td>YYY PTE</td>
														<td>ID CARD MR. YYYYY</td>
														<td>02/05/2016</td>
														<td>02/05/2016</td>
														<td>User</td>
														<td><a href="#">Preview</a>
															<a href="#">Replace</a></td>
													</tr>
													<tr>
														<td>5</td>
														<td>YYY PTE</td>	
														<td>ID CARD MR. ZZZZZ</td>
														<td>02/05/2016</td>
														<td></td>
														<td>User</td>
														<td><a href="#">Preview</a>
															<a href="#">Replace</a></td>
													</tr>
												</table>
											</div>
								</div>
							</section>
						</div>

					
	<script>
			$("#button").click(function(){$("#buttonclick").toggle(); });
			$("#button1").click(function(){$("#buttonclick").toggle(); });
			
		</script> 
		
		
<style>
	#buttonclick .datatables-header {
		display:none;
	}
</style>