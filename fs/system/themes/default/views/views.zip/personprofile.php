
							<section class="panel">
								<header class="panel-heading">
									<div class="panel-actions" style="height:80px">
																
										<!-- a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a-->
										<!--a href="#" class="panel-action panel-action-dismiss" data-panel-dismiss></a-->
										<a class="edit_client amber" href="<?= base_url();?>personprofile/add" data-toggle="tooltip" data-trigger="hover" style="height:45px;font-weight:bold;" data-original-title="Add Person" ><i class="fa fa-plus-circle  amber" style="font-size:16px;height:45px;"></i>Add Person</a>
									</div>
									<h2></h2>
										
								</header>
								<div class="panel-body">
											<div class="col-md-12">
												<div class="col-md-2">
													<select class="form-control input-sm">
														<option>Auditor Name</option>
														<option>Company Name</option>
														<option>Individual Name</option>
													</select>
												</div>
												<div class="col-md-5">
														<input type="text" class="form-control input-sm" id="w2-username" name="username" required placeholder="Search">
												</div>
												<div class="col-md-4">
													<span class="btn btn-primary">Search</span>
													<span class="btn btn-primary">Show All Person</span>
												</div>
												<div class="col-md-12" id="div_person" style="margin-top:10px;">
													<table class="table table-bordered table-striped table-condensed mb-none" id="datatable-default" >
														<thead>
															<tr>
																<th>Type</th>
																<th>ID</th>
																<th>Name</th>
																<th>Phone</th>
																<th>Email</th>
															</tr>
														</thead>
														<tbody>
															<tr>
																<td><span data-target="#modal_edit_person" data-toggle="modal" class="pointer amber">Auditor</span></td>
																<td>0001</td>
																<td>Auditor 1</td>
																<td>+65 28288282</td>
																<td>audit@audit.com</td>
															</tr>
															<tr>
																<td><span data-target="#modal_edit_person" data-toggle="modal" class="pointer amber">XXX LTE</span></td>
																<td>0002</td>
																<td>User 1</td>
																<td>+65 2312545</td>
																<td>u1@xxxx.com</td>
															</tr>
															<tr>
																<td><span data-target="#modal_edit_person" data-toggle="modal" class="pointer amber">XXX LTE</span></td>
																<td>0003</td>
																<td>User 2</td>
																<td>+65 123142</td>
																<td>u2@xxxx.com</td>
															</tr>
															<tr>
																<td><span data-target="#modal_edit_person" data-toggle="modal" class="pointer amber">YYY PTE</span></td>
																<td>0004</td>
																<td>MMMM</td>
																<td>+65 2312545</td>
																<td>mmm@yyy.com</td>
															</tr>
														</tbody>
													</table>
													<br/>
												</div>
											</div>
										
								</div>
					</div>
							<!-- end: page -->
							</section>
						</div>
					</section>
								<div id="modal_person" class="modal fade" >
									<div class="modal-dialog modal-lg">
										<div class="modal-content">
										  <div class="modal-header">
											<header class="panel-heading">
												<h2 class="panel-title">Add Person</h2>
											</header>
										  </div>
											<div class="modal-body">
												<table class="table table-bordered table-striped table-condensed mb-none" >
													<thead>
														<tr>
															<th>Type</th>
															<td>
																<select data-plugin-selectTwo id="select_add_p" class="form-control populate">
																	<optgroup label="Type">
																		<option value="aud">Auditor</option>
																		<option value="comp">Company</option>
																		<option value="indv">Individual</option>
																	</optgroup>
																</select></td>
														</tr>
														<tr id="individual_add_p">
															<th>ID Type</th>
															<td>
																<select data-plugin-selectTwo class="form-control populate">
																	<optgroup label="Type">
																		<option value="AK">Singapore P.R.</option>
																		<option value="FIN">FIN</option>
																		<option value="Pas">Pasport/Other</option>
																	</optgroup>
																</select></td>
														</tr>
														<tr id="shareholder_edit_p">
															<th></th>
															<td><label><input type="checkbox" class="" value=""/>ShareHolder</label>&nbsp;<label><input type="checkbox" class="" value=""/>Director</label></td>
														</tr>
														<tr>
															<th>ID</th>
															<td>
																<div class="input-group"  >
																	<input type="text" class="form-control input-sm" id="w2-username" name="username" required placeholder="Search ID">
																	<span class="input-group-btn">
																		<button class="btn btn-default" type="submit" style="height:30px;"><i class="fa fa-search"></i></button>
																	</span>
																</div>
															</td>				
														</tr>
														<tr>
															<th>Name</th>
															<td><input type="text" class="form-control input-xs" value="Dart"/></td>
														</tr>
														<tr>
															<th>Date Of Birth</th>
															<td><input type="text" class="form-control" data-plugin-datepicker data-date-format="dd/mm/yyyy" /></td>
															
														</tr>
														<tr>
															<th>Address</th>
															<td><label><input type="radio" id="local_add" name="address"/>Local</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																<label><input type="radio" id="foreign_add" name="address"/>Foreign Address</label></td>
														</tr>
														<tr id="tr_local_add">
															<th></th>
															<td>
																<div style="margin-bottom:5px;">
																	<label style="width: 25%;float:left;margin-right: 20px;">Postal Code :</label>
																	<div class="input-group" style="width: 40%;" >
																	<input type="text" class="form-control input-sm" id="w2-username" name="username" required placeholder="Search Postal">
																	<span class="input-group-btn">
																		<button class="btn btn-default" type="submit" style="height:30px;"><i class="fa fa-search"></i></button>
																	</span>
																	</div>
																</div>
																<div style="margin-bottom:5px;">
																	<label style="width: 25%;float:left;margin-right: 20px;">Street Name :</label>
																				<input style="width: 51%;" type="text" class="form-control input-sm" id="w2-username" name="username">
																
																</div>
																<div style="margin-bottom:5px;">
																	<label style="width: 25%;float:left;margin-right: 20px;">Building Name :</label>
																	<input style="width: 51%;" type="text" class="form-control input-sm" id="w2-username" name="username">
																
																</div>
																<div style="margin-bottom:5px;">
																	<label style="width: 25%;float:left;margin-right: 20px;">Unit No :</label>
																				<input style="width: 10%; float: left; margin-right: 10px;" type="text" class="form-control input-sm" id="w2-username" name="username">
																				<label style="float: left; margin-right: 10px;" >-</label>
																				<input style="width: 10%;" type="text" class="form-control input-sm" id="w2-username" name="username" >
																
																</div>
																<div style="margin-bottom:5px;">
																	<label  id="alternate_label_edit" style="width: 25%;float:left;margin-right: 20px;"><input type="checkbox">Alternate Address : </label>
																	<textarea style="width:50%;height:100px;display:none" id="alternate_text_edit"></textarea>
																</div>
															</td>
														</tr>
														<tr id="tr_foreign_add" class="hide">
															
															<th></th>
															<td>
																<label style="width: 25%;float:left;margin-right: 20px;"> Foreign Address :</label>
																<textarea style="width:70%;height:100px;"></textarea>
															</td>
														</tr>
														<tr>
															<th>Nationality</th>
															<td>
																<select data-plugin-selectTwo class="form-control populate">
																	<optgroup label="Nationality">
																		<option value="AK">Malaysia</option>
																		<option value="HI">Singapore</option>
																	</optgroup>
																</select></td>
														</tr>
														<tr>
															<th>Local Fixed Line</th>
															<td><input type="text" class="form-control input-xs" value=""/></td>
														</tr>
														<tr>
															<th>Local Mobile</th>
															<td><input type="text" class="form-control input-xs" value=""/></td>
														</tr>
														<tr>
															<th>Email</th>
															<td><input type="text" class="form-control input-xs" value=""/></td>
														</tr>
														<tr id="represen_add">
															<th>Representative</th>
															<td><input type="text" class="form-control input-xs" value=""/></td>
														</tr>
														
													</thead>
												</table>
												
											</div>
											<div class="modal-footer">
												<div class="row">
													<div class="col-md-12 text-right">
														<!--button class="btn btn-primary modal-confirm">Confirm</button-->
														<button class="btn btn-primary modal-dismiss">Save</button>
														<button class="btn btn-default modal-dismiss">Cancel</button>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div id="modal_edit_person" class="modal fade" >
									<div class="modal-dialog modal-lg">
										<div class="modal-content">
										  <div class="modal-header">
											<header class="panel-heading">
												<h2 class="panel-title">Edit Person</h2>
											</header>
										  </div>
											<div class="modal-body">
												<table class="table table-bordered table-striped table-condensed mb-none" >
													<thead>
														<tr>
															<th>Type</th>
															<td>
																<select data-plugin-selectTwo id="select_edit_p" class="form-control populate">
																	<optgroup label="Type">
																		<option value="aud">Auditor</option>
																		<option value="comp">Company</option>
																		<option value="indv">Individual</option>
																	</optgroup>
																</select></td>
														</tr>
														<tr id="individual_edit_p">
															<th>ID Type</th>
															<td>
																<select data-plugin-selectTwo class="form-control populate">
																	<optgroup label="Type">
																		<option value="AK">SIN Citizen</option>
																		<option value="HI">SIN PR</option>
																		<option value="FIN">FIN</option>
																		<option value="Pas">Pasport/Other</option>
																	</optgroup>
																</select></td>
														</tr>
														<tr id="company_edit_p">
															<th>UEN</th>
															<td><input type="text" class="form-control"></td>
														</tr>
														<tr id="shareholder_edit_p">
															<th></th>
															<td><label><input type="checkbox" class="" value=""/>ShareHolder</label>&nbsp;<label><input type="checkbox" class="" value=""/>Director</label></td>
														</tr>
														<tr>
															<th>ID</th>
															<td>
																<div class="input-group"  >
																	<input type="text" class="form-control input-sm" id="w2-username" name="username" required placeholder="Search ID">
																	<span class="input-group-btn">
																		<button class="btn btn-default" type="submit" style="height:30px;"><i class="fa fa-search"></i></button>
																	</span>
																</div>
															</td>				
														</tr>
														<tr>
															<th>Name</th>
															<td><input type="text" class="form-control input-xs" value="Dart"/></td>
														</tr>
														<tr>
															<th>Date Of Birth</th>
															<td><input type="text" class="form-control" data-plugin-datepicker data-date-format="dd/mm/yyyy" /></td>
															
														</tr><tr>
															<th>Address</th>
															<td><label><input type="radio" id="local_edit" name="address"/>Local</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																<label><input type="radio" id="foreign_edit" name="address"/>Foreign Address</label></td>
														</tr>
														<tr id="tr_local_edit">
															<th></th>
															<td>
																<label style="width: 25%;float:left;margin-right: 20px;">Postal Code :</label>
																<div class="input-group" style="width: 40%;" >
																<input type="text" class="form-control input-sm" id="w2-username" name="username" required placeholder="Search Postal">
																<span class="input-group-btn">
																	<button class="btn btn-default" type="submit" style="height:30px;"><i class="fa fa-search"></i></button>
																</span>
																</div>
																<label style="width: 25%;float:left;margin-right: 20px;">Street Name :</label>
																				<input style="width: 51%;" type="text" class="form-control input-sm" id="w2-username" name="username">
																<label style="width: 25%;float:left;margin-right: 20px;">Building Name :</label>
																<input style="width: 51%;" type="text" class="form-control input-sm" id="w2-username" name="username">
																<label style="width: 25%;float:left;margin-right: 20px;">Unit No :</label>
																				<input style="width: 10%; float: left; margin-right: 10px;" type="text" class="form-control input-sm" id="w2-username" name="username">
																				<label style="float: left; margin-right: 10px;" >-</label>
																				<input style="width: 10%;" type="text" class="form-control input-sm" id="w2-username" name="username" >
																<label  id="alternate_label_edit" style="width: 25%;float:left;margin-right: 20px;"><input type="checkbox">Alternate Address : </label>
																<textarea style="width:50%;height:100px;display:none" id="alternate_text_edit"></textarea>
															</td>
														</tr>
														<tr id="tr_foreign_edit" style="display:none;">
															
															<td></td>
															<td>
																<label style="width: 25%;float:left;margin-right: 20px;"> Foreign Address :</label>
																<textarea style="width:50%;height:100px;"></textarea>
															</td>
														</tr>
														<tr>
															<th>Nationality</th>
															<td>
																<select data-plugin-selectTwo class="form-control populate">
																	<optgroup label="Nationality">
																		<option value="AK">Malaysia</option>
																		<option value="HI">Singapore</option>
																	</optgroup>
																</select></td>
														</tr>
														<tr>
															<th>Local Fixed Line</th>
															<td><input type="text" class="form-control input-xs" value=""/></td>
														</tr>
														<tr>
															<th>Local Mobile</th>
															<td><input type="text" class="form-control input-xs" value=""/></td>
														</tr>
														<tr>
															<th>Email</th>
															<td><input type="text" class="form-control input-xs" value=""/></td>
														</tr>
														<tr id="represen_edit">
															<th>Representative</th>
															<td><input type="text" class="form-control input-xs" value=""/></td>
														</tr>
														
													</thead>
												</table>
												
											</div>
											<div class="modal-footer">
												<div class="row">
													<div class="col-md-12 text-right">
														<!--button class="btn btn-primary modal-confirm">Confirm</button-->
														<button class="btn btn-primary modal-dismiss">Save</button>
														<button class="btn btn-default modal-dismiss">Cancel</button>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
									
			
<style>
	#div_person .datatables-header {
		display:none;
	}
</style>

<script>
			$("#individual_edit_p").hide();
			$("#company_edit_p").hide();
			$("#shareholder_edit_p").hide();
			 $("#represen_edit").hide();
			$("#individual_add_p").hide();
			$("#company_add_p").hide();
			 $("#represen_add").hide();
			$("#shareholder_add_p").hide();
	$("#select_edit_p").on('change',function(){
			$("#individual_edit_p").hide();
			$("#company_edit_p").hide();
			$("#shareholder_edit_p").hide();
			 $("#represen_edit").hide();
		if ($(this).val() == 'comp'){
			$("#company_edit_p").show();
			 $("#represen_edit").show();
		}else if ($(this).val() == 'indv'){
			$("#individual_edit_p").show();
			$("#shareholder_edit_p").show();
		}
	});
	$("#select_add_p").on('change',function(){
			$("#individual_add_p").hide();
			$("#company_add_p").hide();
			 $("#represen_add").hide();
			$("#shareholder_add_p").hide();
		if ($(this).val() == 'comp'){
			$("#company_add_p").show();
			 $("#represen_add").show();
		}else if ($(this).val() == 'indv'){
			$("#individual_edit_p").show();
			$("#shareholder_edit_p").show();
		}
	});
	$("#local_add").click(function() {
		$("#tr_foreign_add").hide();
		$("#tr_local_add").show();
	});
	$("#foreign_add").click(function() {
		$("#tr_foreign_add").show();
		$("#tr_local_add").hide();
	});
	$("#local_edit").click(function() {
		$("#tr_foreign_edit").hide();
		$("#tr_local_edit").show();
	});
	$("#foreign_edit").click(function() {
		$("#tr_foreign_edit").show();
		$("#tr_local_edit").hide();
	});
	$("#alternate_label_edit").click(function() {
		$("#alternate_text_edit").toggle();
	});
	$("#alternate_label_add").click(function() {
		$("#alternate_text_add").toggle();
	});
</script>

